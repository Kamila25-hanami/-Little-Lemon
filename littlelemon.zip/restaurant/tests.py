from django.test import TestCase
from .models import Booking

class BookingModelTest(TestCase):
    def setUp(self):
        Booking.objects.create(first_name="John", reservation_date="2025-01-15", reservation_slot="12:00")

    def test_booking_creation(self):
        booking = Booking.objects.get(first_name="John")
        self.assertEqual(booking.reservation_date, "2025-01-15")
